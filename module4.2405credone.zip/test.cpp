// test.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Merlin Martinez
// SNHU - CS405
//
#include "pch.h"

// The global test environment setup and tear down.
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

//create our Test class to house shared data between tests.
// you should not need to change anything here 

class CollectionTest : public ::testing::Test
{
protected:
    // Create a smart point to hold the collection.
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new collection to be used in the test.
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // Erase all elements in the collection, if any remain.
        collection->clear();
        // Free the pointer.
        collection.reset(nullptr);
    }

    // Helper function to add random values from 0 to 99 count times to the collection.
    void add_entries(int count)
    {
        if (count > 0)
        {
            for (auto i = 0; i < count; ++i)
            {
                collection->push_back(rand() % 100);
            }
        }
    }
};

// runs multiple times with different test data for each run.
struct ParameterizedCollectionTest : CollectionTest, ::testing::WithParamInterface<int>
{
    ParameterizedCollectionTest() { }
};

INSTANTIATE_TEST_CASE_P(CollectionSizes, ParameterizedCollectionTest, ::testing::Values(0, 1, 5, 10));


/*
 * When should you use the EXPECT_xxx or ASSERT_xxx macros?
 * Use ASSERT when failure should terminate processing, such as the reason for the test case.
 * Use EXPECT when failure should notify, but processing should continue.
 *
 * Prior to calling all TEST_F defined methods,
 * CollectionTest::StartUp is called.
 *
 * Following this all TEST_F defined methods,
 * CollectionTest::TearDown is called
 */

 // A collection smart pointer is not null.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // Test that collection created.
    ASSERT_TRUE(collection);

    // Test that collection pointer is not equal to nullptr.
    ASSERT_NE(collection.get(), nullptr);
}

// A collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // Test that collection is empty.
    ASSERT_TRUE(collection->empty());

    // Test that if collection empty, then size must be 0.
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //    FAIL();
 //}

// TODO: Create a test to verify adding a single value to an empty collection
 // Test to verify adding a single value to an empty collection.
TEST_F(CollectionTest, CanAddToEmptyCollection)
{
    // Test if the collection is empty.
    EXPECT_TRUE(collection->empty());

    // Test  if the collection is empty, then the size must be 0.
    EXPECT_EQ(collection->size(), 0);

    // Adds one element to the collection.
    add_entries(1);

    // Test if the collection is not empty.
    ASSERT_FALSE(collection->empty());

    // Test if the collection size is 1.
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to an empty collection.
TEST_F(CollectionTest, CanAddFiveValuesToCollection)
{
    // Test that collection is empty.
    EXPECT_TRUE(collection->empty());

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    // Add five elements to the collection.
    add_entries(5);

    // Test that collection is not empty.
    ASSERT_FALSE(collection->empty());

    // Test that collection size is 5.
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries.
TEST_P(ParameterizedCollectionTest, MaxSizeGreaterThanSize)
{
    // Test that collection is empty.
    EXPECT_TRUE(collection->empty());

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    // Add number of elements specified by the parameter to the collection.
    add_entries(GetParam());

    // Test that collection size matches parameter value.
    ASSERT_EQ(collection->size(), GetParam());

    // Test that collection max size is greater than collection size.
    ASSERT_GT(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entriesTEST_P(ParameterizedCollectionTest, CapacityGreaterThanOrEqualToSize)
TEST_P(ParameterizedCollectionTest, CapacityGreaterThanOrEqualToSize)
{
    
    EXPECT_TRUE(collection->empty());  // Test that collection is empty.


    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    // Add number of elements specified by the parameter to the collection.
    add_entries(GetParam());

    // Test that collection size matches parameter value.
    ASSERT_EQ(collection->size(), GetParam());

    // Test that collection max size is greater than collection size.
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
   
    EXPECT_TRUE(collection->empty());  // Test if collection is empty.

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

   
    collection->resize(5);  // Resize the collection to 5.


    // Test that collection size is increased to 5.
    ASSERT_EQ(collection->size(), 5);
}


TEST_F(CollectionTest, ResizeDecreasesCollectionSize)  // Test to verify resizing decreases the collection.
{
    
    EXPECT_TRUE(collection->empty()); // Test that collection is empty.

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

   
    add_entries(5);   // Add five elements to the collection.


    // Test that collection is not empty.
    EXPECT_FALSE(collection->empty());

   
    EXPECT_EQ(collection->size(), 5);   // Test that collection size is 5.

  
    collection->resize(2);    // Resize the collection to 2.

    // Test that collection size is decreased to 2.
    ASSERT_EQ(collection->size(), 2);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeCollectionSizeToZero)
{
    
    EXPECT_TRUE(collection->empty());  // Test that collection is empty.

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

   
    add_entries(5);   // Add five elements to the collection.



    EXPECT_FALSE(collection->empty());      // Test if the collection is empty or not.

   
    EXPECT_EQ(collection->size(), 5);   // Test that collection size is 5.

   
    collection->resize(0);   // Resize the collection to zero.

    // Test that collection size is decreased to zero.
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearCollection)
{
   
    EXPECT_TRUE(collection->empty());   // Test that collection is empty. 

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    
    add_entries(5);   // Add five elements to the collection.

    // Test if the collection is not empty.
    EXPECT_FALSE(collection->empty());

   
    EXPECT_EQ(collection->size(), 5);   // Test if the collection size is 5.

    
    collection->clear();  // Clear collection.

  
    ASSERT_TRUE(collection->empty());    // Test that collection is empty.

    // Test that if collection empty, then size must be zero.
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseCollection)
{
    
    EXPECT_TRUE(collection->empty());  // Test if the collection is empty.

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    // Add five elements to the collection.
    add_entries(5);

   
    EXPECT_FALSE(collection->empty());   // Test that collection is not empty.

    // Test that collection size is 5.
    EXPECT_EQ(collection->size(), 5);

    
    collection->erase(collection->begin(), collection->end());  // Erase the collection.


    ASSERT_TRUE(collection->empty());       // Test that collection is empty.

    // Test that if collection empty, then size must be zero.
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreaseCollectionCapacity)
{
   
    EXPECT_TRUE(collection->empty());   // Test that collection is empty.

    // Test that if collection empty, then size must be zero.
    EXPECT_EQ(collection->size(), 0);

    // Test that if collection empty, then capacity must be zero.
    EXPECT_EQ(collection->capacity(), 0);

    collection->reserve(5);  //  increase the collection.


  
    ASSERT_TRUE(collection->empty());   // Test if the collection is empty.

   
    ASSERT_EQ(collection->size(), 0);   // Test that the size is still zero.

    // Test that the capacity is greater than size.
    ASSERT_GT(collection->capacity(), collection->size());
}

// Test to verify assign adds the specified number of elements and values.
TEST_F(CollectionTest, AssignValuesToCollection)
{
   
    EXPECT_TRUE(collection->empty());   // Test that collection is empty.

   
    EXPECT_EQ(collection->size(), 0); // Test that if collection empty, then the size must be zero.

    collection->assign(5, 10);

  
    ASSERT_FALSE(collection->empty());   // Test if the collection is not empty.


   
    ASSERT_EQ(collection->size(), 5);   // Test if the collection size is 5.

    for (int i = 0; i < 5; i++)
    {
        ASSERT_EQ(collection->at(i), 10);
    }
}

/**
 Negative Test: Test adding a value to a collection that is in max_size. 
**/

TEST_F(CollectionTest, AddValueToMaxSizeCollection)
{
    std::vector<int> vec;
    vec.resize(vec.max_size());
    ASSERT_THROW(vec.push_back(42), std::length_error);
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    ::testing::AddGlobalTestEnvironment(new Environment);
    return RUN_ALL_TESTS();
}